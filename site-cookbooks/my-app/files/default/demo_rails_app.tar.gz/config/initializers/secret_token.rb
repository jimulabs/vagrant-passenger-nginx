# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
DemoRailsApp::Application.config.secret_token = 'a1fe2b3d6b60722d055050accb2bf3cd4908cab5be43b3da6cb9cc76c24e0d33b38644bc12f1a62c3393a9560f48ef1cb104a79d25ba002d7c4cff6d237200c8'
